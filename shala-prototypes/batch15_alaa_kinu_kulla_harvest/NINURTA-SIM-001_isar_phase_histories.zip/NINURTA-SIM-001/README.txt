NINURTA-SIM-001 — Synthetic ISAR phase histories (Sala-grade ground truth)
BahyWay.Ecosystem v4.0 — deterministic, seed 0x4E494E55 (mulberry-class NumPy PCG64)

Three Tribes, raw complex slow-time x fast-time phase histories BEFORE image formation:
  ship_pitch_drift  : 25 scatterers, omega=0.12 rad/s, translational drift 1.8 m  -> autofocus (Apsu) required
  aircraft_turn     : 29 scatterers, omega=0.30 rad/s, drift 0.6 m
  space_tumbler     : 13 scatterers, omega=0.55 rad/s, drift 0 (clean reference)

Each .c64 = complex64 LE array [512 pulses x 256 range bins], row-major.
Each .groundtruth.json = exact scatterer constellation + motion covenant (Theta).
Processing covenant: range profiles exist per pulse already (bandwidth folded in);
cross-range forms by FFT across slow time; Doppler axis = omega x cross-range.
Verify sha256 against manifest.json before any ingest (Kaniku receipt).
REHEARSAL-GRADE DATA: proves the chain; real archives arrive via PB-DATA-001/002.
